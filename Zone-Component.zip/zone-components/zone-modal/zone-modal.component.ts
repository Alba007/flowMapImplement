import {GeojsonValidatorService} from './../../../../services/geojson-validator.service';
import {
    ApplicationRef,
    ChangeDetectorRef,
    Component,
    ComponentRef,
    EventEmitter,
    Input,
    OnInit,
    Output,
    Optional,
    Inject
} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import {Zone} from '../../../../models/Zone';
import {ZoneService} from '../../../../services/administration/zone.service';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import * as L from 'leaflet';
import {latLng, tileLayer} from 'leaflet';
import {IMultiPolygon} from '../../../../models/IMultiPolygon';
import {NotificationService} from '../../../../services/notification.service';

@Component({
    selector: 'app-zone-modal',
    templateUrl: './zone-modal.component.html',
    styleUrls: ['./zone-modal.component.scss']
})
export class ZoneModalComponent implements OnInit {
    @Input() insertedData: Zone;
    @Input() self: ComponentRef<ZoneModalComponent>;
    @Output() public modalStatus: EventEmitter<string> = new EventEmitter();


    areaSpace: any;
    googleMaps: any;
    hasDraw = false;
    map: L.Map;
    options: any;
    zoneForm: FormGroup;
    modify: boolean;
    bounds: any;
    tempZone: Zone;
    layers: any[] = [];
    drawOptions: any;
    myMulti: IMultiPolygon;
    drawnZone: any;

    constructor(
        private zoneService: ZoneService,
        @Optional() private dialogRef: MatDialogRef<ZoneModalComponent>,
        @Optional() @Inject(MAT_DIALOG_DATA) private data: Zone,
        private changeDetectorRef: ChangeDetectorRef,
        private notificationService: NotificationService,
        private GJV: GeojsonValidatorService,
        private appRef: ApplicationRef) {


    }

    public get f() {
        return this.zoneForm.controls;
    }

    ngOnInit() {
        this.insertedData = this.data !== null && Object.keys(this.data).length !== 0 ? this.data : this.insertedData;

        this.zoneForm = new FormGroup({
            name: new FormControl('', Validators.compose([Validators.required, Validators.minLength(4)])),
            area: new FormControl(this.prettyJson(null))
        });
        this.initData(this.insertedData);
        this.initMap();
    }

    close() {
        this.self ? this.self.destroy() : this.dialogRef.close('Closed');
        this.appRef.tick();
        this.modalStatus.next('Closed');
    }

    saved() {
        this.self ? this.self.destroy() : this.dialogRef.close('Saved');
        this.appRef.tick();
        this.modalStatus.next('Saved');
    }

    initData(data) {
        if (data == null) {
            this.modify = false;
            this.tempZone = {
                name: '',
                area: this.prettyJson('')
            };
            this.myMulti = {
                type: null,
                coordinates: null
            };

            this.areaSpace = this.prettyJson({
                'type': ' ',
                'coordinates': [
                    []
                ]
            });

        } else {
            this.modify = true;
            this.tempZone = JSON.parse(JSON.stringify(this.insertedData));
            this.zoneForm.patchValue({
                name: this.tempZone.name,
                area: this.prettyJson(this.tempZone.area)
            });
            this.myMulti = this.tempZone.area;
            this.areaSpace = this.prettyJson(this.tempZone.area);

        }
    }

    initMap() {
        this.googleMaps = tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
            maxZoom: 18,
            // Remove this for other base layers only google needs it
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
            detectRetina: true
        });
        this.options = {
            layers: [this.googleMaps],
            zoom: 8,
            center: latLng([41.9028, 12.4964]),
            zoomControl: false
            // Hide deafult zoom control so u can use costum
        };
        if (this.modify && this.insertedData.area !== null) {
            this.hasDraw = true;
            // draw current zone
            const geoPoly = L.GeoJSON.geometryToLayer(this.insertedData.area);

            this.drawnZone = new L.FeatureGroup([geoPoly]);
            this.layers.push(this.drawnZone);
            this.drawOptions = {
                position: 'topleft',
                draw: {
                    marker: false,
                    polyline: false,
                    circle: false,
                    rectangle: false,
                    circlemarker: false,
                    polygon: true,
                    multipolygon: false
                },
                edit: {
                    featureGroup: this.drawnZone
                }
            };
            this.bounds = L.geoJSON(this.insertedData.area).getBounds();
        } else {
            this.drawOptions = {
                position: 'topleft',
                draw: {
                    marker: false,
                    polyline: false,
                    circle: false,
                    rectangle: false,
                    circlemarker: false,
                    polygon: {repeatMode: true}
                }
            };
        }

    }

    onMapReady(map: L.Map) {
        this.map = map;
        if (this.bounds) {
            map.fitBounds(this.bounds);
        }
        const that = this;
        map.on('draw:created', function (e) {
            const layer = (e as L.DrawEvents.Created).layer;
            const shape = layer.toGeoJSON();
            that.pushPolygons(shape.geometry);
            const createdZone = new L.FeatureGroup();
            createdZone.addLayer(layer);
            that.hasDraw = true;

            that.areaSpace = that.prettyJson((layer as L.Polygon).toGeoJSON().geometry);
            that.changeDetectorRef.detectChanges();
        });
        map.on('draw:edited', function (e) {
            const layers = (e as L.DrawEvents.Edited).layers;
            const editedZone = new L.FeatureGroup();
            layers.eachLayer(layer => {
                if (layer instanceof L.Polygon) {
                    editedZone.addLayer(layer);
                    that.zoneForm.patchValue({area: that.prettyJson((layer as L.Polygon).toGeoJSON().geometry)});
                    that.areaSpace = that.prettyJson((layer as L.Polygon).toGeoJSON().geometry);
                }
            });
            that.hasDraw = true;
            that.changeDetectorRef.detectChanges();

        });
        map.on('draw:deleted', function (e) {
            map.eachLayer(layer => {
                if (layer instanceof L.Polygon) {
                    map.removeLayer(layer);
                }
            });
            that.hasDraw = false;
            that.drawOptions = {
                position: 'topleft',
                draw: {
                    marker: false,
                    polyline: false,
                    circle: false,
                    rectangle: false,
                    circlemarker: false,
                    polygon: true,
                    multipolygon: true,
                }
            };
            that.zoneForm.patchValue({
                area: null
            });
            that.areaSpace = null;
            that.changeDetectorRef.detectChanges();
        });


    }

    saveAndClose() {
        if (this.checkObj()) {
            const that = this;
            const dataToSave = this.zoneForm.getRawValue();
            dataToSave.area = JSON.parse(this.areaSpace);
            if (this.modify) {
                dataToSave.id = this.tempZone.id;
                this.zoneService.updateZone(dataToSave).subscribe(
                    response => {
                        this.notificationService.addToastSuccess('Successfully Updated', 'Success', {});
                        this.saved();
                    }
                );
            } else {
                this.zoneService.createZone(dataToSave).subscribe(
                    response => {
                        this.notificationService.addToastSuccess('Successfully saved!', 'Success', {});
                        this.saved();
                    }
                );
            }
        } else {
            this.notificationService.addToastError('Fix data and save later', 'ZONE NOT VALID', {timeOut: 1000});
        }
    }


    prettyJson(obj): string {
        return JSON.stringify(obj, undefined, 2);
    }

    show() {
        if (this.checkObj()) {
            const l = L.geoJSON(JSON.parse(this.areaSpace) as any);
            if (this.drawnZone) {
                this.drawnZone.removeFrom(this.map);
            }
            this.drawnZone = L.geoJSON(JSON.parse(this.areaSpace) as any).addTo(this.map);
            this.map.fitBounds(l.getBounds());
        } else {
            this.notificationService.addToastError('Fix data and save later', 'ZONE NOT VALID', {timeOut: 1000});
        }
    }

    pushPolygons(poly) {
        if (this.myMulti.type === null) {
            this.myMulti.type = 'Polygon';
            this.myMulti.coordinates = poly.coordinates;
        } else {
            if (this.myMulti.type === 'Polygon') {
                const first = this.myMulti.coordinates;
                this.myMulti.coordinates = [];
                this.myMulti.coordinates.push(first);
            }
            this.myMulti.type = 'MultiPolygon';
            this.myMulti.coordinates.push(poly.coordinates);
        }
        this.zoneForm.patchValue({
            area: this.prettyJson(this.myMulti)
        });
    }

    checkObj() {
        try {
            const el = JSON.parse(this.areaSpace);
            return this.GJV.isPolygon(el, '') || this.GJV.isMultiPolygon(el, '');
        } catch (e) {
            return false;
        }
    }

}
