import { DataTableInputOptions } from './../../../../shared-module/module-assets-dataTable/models/dataTableInputOptions';
import {
    AfterViewInit,
    Component,
    ComponentFactoryResolver,
    ComponentRef,
    ElementRef,
    OnDestroy,
    OnInit,
    ViewChild,
    ViewContainerRef
} from '@angular/core';
import { MatDialog, MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { Zone } from '../../../../models/Zone';
import * as L from 'leaflet';
import { geoJSON, latLng, tileLayer } from 'leaflet';
import { ZoneModalComponent } from '../zone-modal/zone-modal.component';
import { ConfirmationModuleComponent } from '../../confirmation-modal/confirmation-modal.component';
import { of as observableOf } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators/catchError';
import { map } from 'rxjs/operators/map';
import { startWith } from 'rxjs/operators/startWith';
import { switchMap } from 'rxjs/operators/switchMap';
import { merge } from 'rxjs/observable/merge';
import { Page } from '../../../../models/Page';
import { ZoneService } from '../../../../services/administration/zone.service';
import { UtilService } from '../../../../services/util.service';
import { NotificationService } from '../../../../services/notification.service';
import { TableExportService } from '../../../../services/administration/table-export.service';
import { ImportComponentComponent } from '../../import-component/import-component.component';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-zone-table',
    templateUrl: './zone-table.component.html',
    styleUrls: ['./zone-table.component.scss']
})
export class ZoneTableComponent implements OnInit, AfterViewInit, OnDestroy {

    @ViewChild('container', { read: ViewContainerRef }) viewContainerRef: ViewContainerRef;
    profileModal: ComponentRef<ZoneModalComponent>;
    ref: ComponentRef<ZoneModalComponent>;

    map: L.Map;
    dialogRef: any;
    dataSource: MatTableDataSource<Zone> = new MatTableDataSource();
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fileToUpload') filer: ElementRef;
    @ViewChild('showFirst') showCol: ElementRef;
    @ViewChild('showMap') showMap: ElementRef;


    layers = [];
    optionsMap: any;
    googleMaps: any;
    displayedColumns: string[] = ['name', 'actions'];
    resultsLength = 0;
    zoneid: any;
    valueFilters: Zone = {
        name: ''
    };
    newFilters = {};
    newAttributeFilters = [];
    newPaginator = {
        page: 0,
        size: 10,
    };
    filters: Page;
    options: DataTableInputOptions;
    fileToUpload: any;
    openedModal = false;

    constructor(private zoneService: ZoneService,
        private modal: MatDialog,
        private util: UtilService,
        private notificationService: NotificationService,
        private tableExportService: TableExportService,
        private componentFactoryResolver: ComponentFactoryResolver) {
    }

    drawTable(dataReceived?) {

        this.dataSource.sort = this.sort;
        this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);
        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
                startWith({}),
                switchMap(() => {
                    this.filters = {
                        needTotal: true,
                        pageNumber: dataReceived ? dataReceived.page : this.newPaginator.page ? this.newPaginator.page : 0,
                        elementPerPage: dataReceived ? dataReceived.size : this.newPaginator.size ? this.newPaginator.size : 10,
                        filter: this.util.cleanOBJ(this.valueFilters)
                    };
                    // this.isLoadingResults = true;
                    return this.zoneService.getZones(this.filters);
                }),
                map(data => {
                    // this.isLoadingResults = false;
                    // this.isRateLimitReached = false;
                    this.resultsLength = data.totalElements;
                    return data;

                }),
                catchError(() => {
                    // this.isLoadingResults = false;
                    // this.isRateLimitReached = true;
                    return observableOf([]);
                })
            ).subscribe((data: any) => {
                this.dataSource.data = data.content;
                this.fillInput();
            });

    }

    showInMap(zone: Zone) {
        this.openedModal = false;
        if (this.ref) {
            this.ref.destroy();
        }

        this.layers.pop();
        this.layers.push(geoJSON(zone as any,
            {
                style: () => ({
                    weight: 2,
                    opacity: 1,
                    color: 'black',
                    fillOpacity: 0.5,
                    fillColor: 'purple'
                })
            })
        );
        const l = L.geoJSON(zone as any);
        this.map.fitBounds(l.getBounds());

        this.showMap.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    addZone(element) {
        if (this.ref) {
            this.ref.destroy();
        }
        this.openedModal = false;
        let options;
        if (window.innerWidth > 640) {
            options = {
                data: element,
                width: '50vw',
                disableClose: true
            };
        } else {
            options = {
                data: element,
                width: '100vw',
                height: '90vh',
                disableClose: true,
                panelClass: 'full-width-dialog'
            };
        }
        this.dialogRef = this.modal.open(ZoneModalComponent, options);
        this.dialogRef.afterClosed().subscribe(result => {
            if (result) {
                if (result === 'Saved') {
                    this.drawTable();
                }
            }
        });
    }

    editZone(element: Zone) {
        if (this.ref) {
            this.ref.destroy();
        }

        this.openedModal = true;

        const factory = this.componentFactoryResolver.resolveComponentFactory(ZoneModalComponent);
        this.ref = this.viewContainerRef.createComponent(factory);
        this.ref.instance.insertedData = element;
        this.ref.instance.self = this.ref;

        const sub: Subscription = this.ref.instance.modalStatus.subscribe(event => {
            console.log(event);
            if (event) {
                this.openedModal = false;
            }
            if (event === 'Saved') {
                this.drawTable();
            }
        });

        if (window.innerWidth < 640) {
            this.showCol.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }

    deleteZone(zoneid: string) {
        this.zoneService.deleteZone(zoneid).subscribe(
            success => {
                this.notificationService.addToastInfo('Zone deleted!', '', {});
                this.drawTable();

            },
            error => {

            }
        );
    }

    ngOnInit() {
        this.googleMaps = tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', {
            maxZoom: 18,
            // Remove this for other base layers only google needs it
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
            detectRetina: true
        });
        this.optionsMap = {
            layers: [this.googleMaps],
            zoom: 8,
            center: latLng([41.9028, 12.4964]),
            zoomControl: false
        };
    }

    ngAfterViewInit() {
        this.drawTable();
    }

    openConfirmationModal(id: string) {
        if (this.ref) {
            this.ref.destroy();
        }
        this.openedModal = false;

        let ispushed = false;
        const efects = [];
        this.zoneService.getZoneById(id).subscribe(res => {
            let results: any;
            results = res;
            this.zoneid = results.id;

            if (this.zoneid === id && !ispushed) {
                efects.push({ type: 'zone', element: results.name });
                ispushed = true;
            }
        });
        this.dialogRef = this.modal.open(ConfirmationModuleComponent, {
            data: { data: id, efects: '' },
            width: '600px',
        });
        this.dialogRef.afterClosed().subscribe(result => {
            if (result && result.action === 'confirm') {
                this.deleteZone(result.data);
            } else {
            }
        });

    }

    exportJSON() {
        this.filters.pageNumber = 0;
        this.filters.elementPerPage = 2147483647;
        this.zoneService.getZones(this.filters).subscribe(data => {
            this.tableExportService.exportJSON(data.content, 'Zones');
            this.filters.elementPerPage = this.paginator.pageSize;
            this.filters.pageNumber = this.paginator.pageIndex;
        });
    }

    importJSON(target: any) {
        if ((<any>window).File && (<any>window).FileReader && (<any>window).FileList && (<any>window).Blob) {
            if (target.type === 'application/json') {
                this.zoneService.uploadZones(target).subscribe(
                    data => {
                        const test = {
                            update: (a) => this.zoneService.updateZone(a),
                            data: [...data]
                        };

                        this.dialogRef = this.modal.open(ImportComponentComponent, {
                            data: test,
                            width: '50%'
                        });
                        this.dialogRef.afterClosed().subscribe(result => {
                            this.filer.nativeElement.value = '';
                        });
                        this.drawTable();
                    }
                );
            }
        } else {
            console.log('The File APIs are not fully supported in this browser.');
        }
    }

    onMapReady(mapi: L.Map) {
        this.map = mapi;
    }

    ngOnDestroy() {
        if (this.ref) {
            this.ref.destroy();
        }
    }

    fillInput() {
        const preChoosedFilters = [];
        if (this.newFilters) {
            Object.keys(this.newFilters).forEach(el => {
                const attr = this.newAttributeFilters[Object.keys(this.newFilters).indexOf(el)];
                preChoosedFilters.push({
                    attribute: attr['attribute'],
                    key: el,
                    value: this.newFilters[el]
                });
            });
        }

        this.options = {
            mappings: {
                icon: 'gps_fixed',
                row1_info1: { label: 'zoneName', attribute_path: 'name' },
            },
            multiple_actions: [
                {
                    name: 'Export JSON',
                    icon: 'archive'
                }
            ],
            actions: [
                // {
                //     name: 'Preview',
                //     icon: 'visibility_circle'
                // },
                {
                    name: 'edit',
                    icon: 'border_color'
                },
                {
                    name: 'delete',
                    icon: 'delete'
                }
            ],

            query_options: {
                page: this.newPaginator.page,
                size: this.newPaginator.size,
                total: this.resultsLength,
                filters: preChoosedFilters
            },
            filter_options: [
                {
                    key: 'name',
                    attribute: 'Name',
                    acceptedValue: 'string'
                }
            ],
        };
    }

    queryEvent(event) {
        // filtering
        this.fixFilters(event.query_options);
    }

    multiActions(event) {
        if (event.name === 'Export JSON') {
            if (event.target === 'ALL') {
                this.exportJSON();
            } else {
                this.tableExportService.exportJSON(event.target, 'Profiles');
            }
        }
    }

    fieldActions(event) {
        if (event) {
            console.log(event);
            if (event.name === 'Preview'){
                this.showInMap(event.target.area);
            } else if (event.name === 'edit') {
                this.editZone(event.target);
            } else if (event.name === 'delete') {
                this.openConfirmationModal(event.target.id);
            } else if (event.id) {
                this.showInMap(event.area);
            }
        }
    }

    fixFilters(data) {
        if (data) {
            this.newPaginator = {
                page: data.page,
                size: data.size
            };
            if (data.filters) {
                this.newFilters = {};
                this.newAttributeFilters = [];
                data.filters.forEach(el => {
                    this.newFilters[el.key] = el.value;
                    this.newAttributeFilters.push({ 'attribute': el.attribute });
                });
                this.valueFilters = this.newFilters;
            }
            this.drawTable(data);
        }
    }

}
